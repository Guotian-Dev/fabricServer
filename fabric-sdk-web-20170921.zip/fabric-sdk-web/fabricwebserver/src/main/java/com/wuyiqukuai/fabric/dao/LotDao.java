//package com.wuyiqukuai.fabric.dao;
//
//import java.util.List;
//import java.util.Map;
//
//import org.apache.ibatis.annotations.Mapper;
//
//import com.wuyiqukuai.fabric.domain.Lot;
//
//@Mapper
//public interface LotDao {
//
//	public List<Lot> selectLots();
//
//	public void insertLot(Map<String, Object> map);
//
//	public void updateLotById(Map<String, Object> map);
//
//	public Lot selectLotById(Integer id);
//
//	public void updateLotState(Integer id);
//	
//
//}
