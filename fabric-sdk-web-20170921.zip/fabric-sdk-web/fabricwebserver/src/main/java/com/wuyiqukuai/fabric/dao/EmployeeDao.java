package com.wuyiqukuai.fabric.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.wuyiqukuai.fabric.domain.Employee;

//@Mapper
//public interface EmployeeDao {
//	
//	public List<Employee> selectEmployee();
//
//	public Employee selectEmployeeById(int id);
//
//	public List<Employee> selectEmpPage(Map<String, Object> pageRows);
//
//	public int selectEmpCount();
//
//}
