//package com.wuyiqukuai.fabric.service.impl;
//
//import java.util.List;
//import java.util.Map;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.wuyiqukuai.fabric.dao.EmployeeDao;
//import com.wuyiqukuai.fabric.domain.Employee;
//import com.wuyiqukuai.fabric.service.EmployeeService;
//
//@Service
//public class EmployeeServiceImpl implements EmployeeService{
//	
//	@Autowired
////	private EmployeeDao employeeDao;
//	
//	@Override
//	public List<Employee> getEmps() {
////		return employeeDao.selectEmployee();
//	}
//
//	@Override
//	public Employee getEmpObjById(int id) {
//		return employeeDao.selectEmployeeById(id);
//	}
//
//	@Override
//	public List<Employee> getEmpPage(Map<String, Object> pageRows) {
//		return employeeDao.selectEmpPage(pageRows);
//	}
//
//	@Override
//	public int getEmpCount() {
//		return employeeDao.selectEmpCount();
//	}
//
//}
