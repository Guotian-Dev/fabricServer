//package com.wuyiqukuai.fabric.domain;
//
//import java.util.List;
//
///**
// * 大json
// * @author PC
// *
// */
//public class FileInfoJson {
////	"'file_total': 9,"+
////	        "'file_begin': 1,"+
////	        "'file_end': 9,"+
////	        "'file_group': ["+
//	
//	private String file_total;
//	private String file_begin;
//	private String file_end;
//	private List<FileMetaData> file_group;
//	
//	public String getFile_total() {
//		return file_total;
//	}
//	public void setFile_total(String file_total) {
//		this.file_total = file_total;
//	}
//	public String getFile_begin() {
//		return file_begin;
//	}
//	public void setFile_begin(String file_begin) {
//		this.file_begin = file_begin;
//	}
//	public String getFile_end() {
//		return file_end;
//	}
//	public void setFile_end(String file_end) {
//		this.file_end = file_end;
//	}
//	public List<FileMetaData> getFile_group() {
//		return file_group;
//	}
//	public void setFile_group(List<FileMetaData> file_group) {
//		this.file_group = file_group;
//	}
//	@Override
//	public String toString() {
//		return "FileInfoJson [file_total=" + file_total + ", file_begin=" + file_begin + ", file_end=" + file_end
//				+ ", file_group=" + file_group + "]";
//	}
//	
//}
