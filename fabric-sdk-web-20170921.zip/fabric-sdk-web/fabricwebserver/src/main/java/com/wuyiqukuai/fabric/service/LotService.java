//package com.wuyiqukuai.fabric.service;
//
//import java.util.List;
//import java.util.Map;
//
//import com.wuyiqukuai.fabric.domain.Lot;
//
//public interface LotService {
//
//	public List<Lot> getLots();
//
//	public void addLot(Map<String, Object> map);
//
//	public Lot getLotById(Integer id);
//
//	public void modifyLotById(Map<String, Object> map);
//
//	public void deleteLotById(Integer id);
//
//	public void jxAddLot(); 
//
//}
